package com.saavncasestudy;

import java.io.IOException;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.mapreduce.Reducer;

public class SaavnCombiner extends Reducer<SaavnKeyWritable, IntWritable, SaavnKeyWritable, IntWritable>{
	
	@Override
	protected void reduce(SaavnKeyWritable key, Iterable<IntWritable> values, Context context) throws IOException, InterruptedException {
		
		int count = 0;
        for(IntWritable val : values) {
        	count = count + val.get();
        }

        context.write(key, new IntWritable(count));
	}
}
