package com.saavncasestudy;

import java.io.IOException;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class SaavnMapper extends Mapper<LongWritable, Text, SaavnKeyWritable, IntWritable > {
	@Override

	public void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException
	{
		try {			
			String[] valueItems = value.toString().split(",");			
			String songId = valueItems[0]; 
		
			int datePart = Integer.parseInt(valueItems[4].toString().split("-")[2]);
			int hour = Integer.parseInt(valueItems[3].toString());
			if(!songId.isEmpty() && !songId.equals("(null)") && datePart >= 24 && datePart <=30)
			{				
				SaavnKeyWritable outputKey = new SaavnKeyWritable(new IntWritable(datePart), new Text(songId));
				IntWritable weight = new IntWritable(hour * 1);
				context.write(outputKey, weight);
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}	
}
