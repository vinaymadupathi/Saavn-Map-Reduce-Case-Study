package com.saavncasestudy;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.mapreduce.Partitioner;

public class SaavnPartitioner extends Partitioner<SaavnKeyWritable, IntWritable > {

public int getPartition(SaavnKeyWritable key, IntWritable value, int numReduceTasks) {
	 int date = key.getDatePart();
	 return date - 24;
}
}
